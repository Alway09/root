#ifndef CONNECTION_H
#define CONNECTION_H
#include <QSqlDatabase>
#include <QSqlTableModel>

QSqlTableModel *StudentsTableModel;
QSqlTableModel *GroupsTableModel;
QSqlDatabase DB;

int testI;

bool ConnectToDB()
{
    DB=QSqlDatabase::addDatabase("QSQLITE");
    DB.setDatabaseName("testDB");
    bool f= DB.open();

    if (f)
    {
        StudentsTableModel=new QSqlTableModel(0,DB);
        GroupsTableModel=new QSqlTableModel(0,DB);

        StudentsTableModel->setTable("students");
        GroupsTableModel->setTable("groups");

        StudentsTableModel->setEditStrategy(QSqlTableModel::OnRowChange);
        //StudentsTableModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
        GroupsTableModel->setEditStrategy(QSqlTableModel::OnRowChange);

        StudentsTableModel->select();
        GroupsTableModel->select();

        StudentsTableModel->setHeaderData(1,Qt::Horizontal,QString::fromLocal8Bit("ФИО"));

        GroupsTableModel->setHeaderData(1,Qt::Horizontal,QString::fromLocal8Bit("Название группы"));
    }
    return f;
}

#endif // CONNECTION_H
