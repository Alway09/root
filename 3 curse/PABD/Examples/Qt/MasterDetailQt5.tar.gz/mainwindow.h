#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex>
#include <QSqlRecord>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    int GenerateID(QString IdName,QString NameTable);

private slots:
    void currentGroupChanged(const QModelIndex &index);

    void on_AddToGroup_clicked();
    void on_DelFromGroup_clicked();
    void on_AddToStudent_clicked();
    void on_DelFromStudent_clicked();
};

#endif // MAINWINDOW_H
