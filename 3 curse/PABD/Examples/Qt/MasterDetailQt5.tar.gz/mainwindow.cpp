#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "Connection.h"

#include <QSqlError>
#include <QSqlField>
#include <QSqlRecord>
#include <QSqlQuery>
#include <QDebug>

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    if (!ConnectToDB())
    {
        QMessageBox::critical(this,QString::fromLocal8Bit("Ошибка открытия базы данных"), DB.lastError().text());
        exit(1);
    }
    ui->setupUi(this);

    ui->GroupsView->setModel(GroupsTableModel);
    ui->StudentsView->setModel(StudentsTableModel);

    ui->StudentsView->hideColumn(0);
    ui->StudentsView->hideColumn(2);
    ui->GroupsView->hideColumn(0);

    connect(ui->GroupsView->selectionModel(),SIGNAL(currentRowChanged(QModelIndex,QModelIndex)),
            this,SLOT(currentGroupChanged(QModelIndex)));
}

void MainWindow::currentGroupChanged(const QModelIndex &index)
{
    if (index.isValid())
    {
       QSqlRecord record=GroupsTableModel->record(index.row());
       int id=record.value("IdGr").toInt();
       StudentsTableModel->setFilter(QString("IdGr=%1").arg(id));
    } else StudentsTableModel->setFilter("IdGr=-1");
    StudentsTableModel->select();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_AddToGroup_clicked()
{
    int Row=GroupsTableModel->rowCount();
    GroupsTableModel->insertRow(Row);
    QModelIndex index=GroupsTableModel->index(Row,1);
    ui->GroupsView->setCurrentIndex(index);
    ui->GroupsView->edit(index);
}

void MainWindow::on_DelFromGroup_clicked()
{
    ui->GroupsView->setFocus();
    QModelIndex index=ui->GroupsView->currentIndex();
    if (!index.isValid()) return;

    QSqlTableModel StudList;
    int IdGr=GroupsTableModel->record(index.row()).field("IdGr").value().toInt();
    StudList.setTable("students");
    StudList.setFilter(QString("IdGr=%1").arg(IdGr));
    StudList.select();

    if (StudList.rowCount()==0)
    {
        GroupsTableModel->removeRow(index.row());
    } else
    {
        QMessageBox::critical(this,QString::fromLocal8Bit("Удаление группы"),
                              QString::fromLocal8Bit("Удаление невозможно. В группе есть студенты"));
    }

}

void MainWindow::on_AddToStudent_clicked()
{
    int Row=StudentsTableModel->rowCount();

    QSqlRecord rec=StudentsTableModel->record();

    rec.setGenerated("IdSt",false);

    QModelIndex indexGr=ui->GroupsView->currentIndex();
    if (!indexGr.isValid())
    {
        QMessageBox::critical(this,QString::fromLocal8Bit("Добавление студента"),
                              QString::fromLocal8Bit("Не выбрана группа"));
    }
    int IdGr=GroupsTableModel->record(indexGr.row()).field("IdGr").value().toInt();
    rec.setValue("IdGr",IdGr);
    StudentsTableModel->insertRecord(-1,rec);

    QModelIndex index=StudentsTableModel->index(Row,1);
    ui->StudentsView->setCurrentIndex(index);
    ui->StudentsView->edit(index);
}

void MainWindow::on_DelFromStudent_clicked()
{
    QModelIndex index=ui->StudentsView->currentIndex();

    if (!index.isValid()) return;

    StudentsTableModel->removeRow(index.row());
}

int MainWindow::GenerateID(QString IdName,QString NameTable)
{
  QSqlQuery q;
  if (q.exec("select max("+IdName+") from "+NameTable))
  {
      q.first();
      return q.value(0).toInt()+1;
  }
   else return -1;

}
