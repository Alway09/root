#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QBrush>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("test.db");
    db.open();

    plainModel = new QSqlTableModel(0,db);
    plainModel->setTable("t");
    plainModel->select();
    plainModel->setEditStrategy(QSqlTableModel::OnManualSubmit);

    ui->tableView->setModel(plainModel);
    delegateA= new SpinBoxDelegate();
    delegateB= new CheckBoxDelegate();
    ui->tableView->setItemDelegateForColumn(2,delegateA);
    ui->tableView->setItemDelegateForColumn(1,delegateB);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


// Реализация класса SpinBoxDelegate
SpinBoxDelegate::SpinBoxDelegate(QObject *parent)
     : QItemDelegate(parent)
 {
 }

QWidget *SpinBoxDelegate::createEditor(QWidget *parent,
     const QStyleOptionViewItem &/* option */,
     const QModelIndex &/* index */) const
 {
     QSpinBox *editor = new QSpinBox(parent);
     editor->setMinimum(0);
     editor->setMaximum(100);

     return editor;
 }

void SpinBoxDelegate::setEditorData(QWidget *editor,
                                     const QModelIndex &index) const
 {
     int value = index.model()->data(index, Qt::EditRole).toInt();

     QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
     spinBox->setValue(value);
 }

void SpinBoxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                    const QModelIndex &index) const
 {
     QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
     spinBox->interpretText();
     int value = spinBox->value();

     model->setData(index, value, Qt::EditRole);
 }

void SpinBoxDelegate::updateEditorGeometry(QWidget *editor,
     const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
 {
     editor->setGeometry(option.rect);
 }


// Реализация класса CheckBoxDelegate
CheckBoxDelegate::CheckBoxDelegate(QObject *parent)
     : QStyledItemDelegate(parent)
 {
 }

QWidget *CheckBoxDelegate::createEditor(QWidget *parent,
     const QStyleOptionViewItem &/* option */,
     const QModelIndex &/* index */) const
 {
     QCheckBox *editor = new QCheckBox(parent);

     return editor;
 }

void CheckBoxDelegate::setEditorData(QWidget *editor,
                                     const QModelIndex &index) const
 {
     int value = index.model()->data(index, Qt::EditRole).toInt();

     QCheckBox *CheckBox = static_cast<QCheckBox*>(editor);
     if (value>0) CheckBox->setCheckState(Qt::Checked);
       else CheckBox->setCheckState(Qt::Unchecked);
 }

void CheckBoxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                    const QModelIndex &index) const
 {
     QCheckBox *CheckBox = static_cast<QCheckBox*>(editor);
     int value =CheckBox->checkState()==Qt::Checked?1:0;
     model->setData(index, value, Qt::EditRole);
 }

void CheckBoxDelegate::updateEditorGeometry(QWidget *editor,
     const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
 {
     editor->setGeometry(option.rect);
 }


void CheckBoxDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,
                             const QModelIndex &index) const
{
    if (option.state & QStyle::State_Editing)
    {
      painter->fillRect(option.rect,option.palette.HighlightedText);
      QStyledItemDelegate::paint(painter, option, index);
    }
    else
    {
        /*int value = index.model()->data(index).toInt();
        if (value>0) painter->drawText(option.rect.x()+20,option.rect.y()+15,QString::fromLocal8Bit("Да"));
              else painter->drawText(option.rect.x()+20,option.rect.y()+15,QString::fromLocal8Bit("Нет"));*/
        bool _state = index.model()->data(index).toBool();
        QStyleOptionButton _opt;
        _opt.rect.setRect(option.rect.x(),option.rect.y(),option.rect.width(),option.rect.height());

        _initStyleOption(&_opt,_state);
        QStyle *style = QApplication::style();
        style->drawControl(QStyle::CE_CheckBox,&_opt,painter);
    }


}

void CheckBoxDelegate::_initStyleOption(QStyleOptionButton *option,bool state) const
{
    if (!option) return;
    option->state |= QStyle::State_Active;
    option->state |= QStyle::State_Enabled;
    option->state |= state ? QStyle::State_On : QStyle::State_Off;
}

void MainWindow::on_pushButton_clicked()
{
    plainModel->submitAll();
}
