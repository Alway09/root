#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QSpinBox>
#include <QCheckBox>
#include <QPainter>
 #include <QStyledItemDelegate>

#include <QItemDelegate>
#include <QMainWindow>
#include <QtSql>

namespace Ui {
    class MainWindow;
}

// класс SpinBoxDelegate
class SpinBoxDelegate : public QItemDelegate
 {
     Q_OBJECT

 public:
     SpinBoxDelegate(QObject *parent = 0);

     QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                           const QModelIndex &index) const;

     void setEditorData(QWidget *editor, const QModelIndex &index) const;
     void setModelData(QWidget *editor, QAbstractItemModel *model,
                       const QModelIndex &index) const;

     void updateEditorGeometry(QWidget *editor,
         const QStyleOptionViewItem &option, const QModelIndex &index) const;
 };

// класс СheckBoxDelegate
class CheckBoxDelegate : public QStyledItemDelegate
 {
     Q_OBJECT
 private:
    void _initStyleOption(QStyleOptionButton *option,bool state) const;
 public:
     CheckBoxDelegate(QObject *parent = 0);

     QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                           const QModelIndex &index) const;

     void setEditorData(QWidget *editor, const QModelIndex &index) const;
     void setModelData(QWidget *editor, QAbstractItemModel *model,
                       const QModelIndex &index) const;

     void updateEditorGeometry(QWidget *editor,
         const QStyleOptionViewItem &option, const QModelIndex &index) const;
     void paint(QPainter *painter, const QStyleOptionViewItem &option,
                     const QModelIndex &index) const;
 };

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QSqlTableModel *plainModel;
    QSqlDatabase db;
    SpinBoxDelegate *delegateA;
    CheckBoxDelegate *delegateB;
    //QItemDelegate delst;
};

#endif // MAINWINDOW_H
