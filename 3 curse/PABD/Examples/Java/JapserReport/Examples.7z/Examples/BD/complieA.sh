javac -cp ${JASPER_HOME}/dist/jasperreports-5.0.0.jar:${JASPER_HOME}/dist/jasperreports-fonts-5.0.0.jar:. JasperDBDemoA.java
