javac -cp ${JASPER_HOME}/dist/jasperreports-6.8.0.jar:${JASPER_HOME}/ext/fonts/target/jasperreports-fonts-6.8.0.jar:. JasperGroupDemo.java
