import java.util.HashMap;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.view.JasperViewer;
import javax.swing.JFrame;
import java.awt.Dimension;

import java.sql.*;

public class JasperPreview {
  public static void main(String[] args) throws SQLException {

    Connection conn = null;

    System.out.println("Starting");

    try {
      // Открываем соединение с базой
      Class.forName("org.postgresql.Driver");
      conn = DriverManager.getConnection("jdbc:postgresql://localhost/andy", "andy", "andy_postgres");

      JasperReport jasperReport = JasperCompileManager.compileReport("Reports/DBReport.xml");

      // Передаем conn в отчет
      JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport,  new HashMap(),
        conn );

      JasperViewer.viewReport(jasperPrint,false);
 
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } catch (JRException e) {
      e.printStackTrace();
    } finally {
      // Корректно закрываем соединение с базой
      try {
        conn.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    System.out.println("Done.");
  }
}
