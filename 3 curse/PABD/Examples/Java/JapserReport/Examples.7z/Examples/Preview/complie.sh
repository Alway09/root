javac -cp ${JASPER_HOME}/dist/jasperreports-6.8.0.jar:${JASPER_HOME}/ext/fonts/target/jasperreports-fonts-6.8.0.jar:$(echo ${JASPER_HOME}/dist/lib/*.jar | tr ' ' ':'):. JasperPreview.java
