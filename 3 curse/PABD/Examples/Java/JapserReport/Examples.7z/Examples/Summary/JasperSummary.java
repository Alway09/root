import java.util.HashMap;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

import java.sql.*;

public class JasperSummary {
  public static void main(String[] args) throws SQLException {

    Connection conn = null;

    System.out.println("Starting");

    try {
      // Открываем соединение с базой
      Class.forName("org.postgresql.Driver");
      String query = "select NGr,FIO from groups natural join students order by NGr, FIO";
      conn = DriverManager.getConnection("jdbc:postgresql://localhost/postgres", "postgres", "adminpostgres");

      JasperReport jasperReport = JasperCompileManager.compileReport("Reports/SummaryReport.xml");

      // Передаем conn в отчет
      JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport,  new HashMap(),
        conn );

      JasperExportManager.exportReportToPdfFile(jasperPrint, "Reports/SummaryReport.pdf");

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } catch (JRException e) {
      e.printStackTrace();
    } finally {
      // Корректно закрываем соединение с базой
      try {
        conn.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    System.out.println("Done.");
  }
}
