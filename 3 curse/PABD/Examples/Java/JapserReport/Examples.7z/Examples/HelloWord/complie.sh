javac -cp ${JASPER_HOME}/dist/jasperreports-6.2.1.jar:${JASPER_HOME}/dist/jasperreports-fonts-6.2.1.jar:. JasperHello.java
