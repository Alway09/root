import java.util.HashMap;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JRResultSetDataSource;

import java.sql.*;

public class JasperParameters {
  public static void main(String[] args) throws SQLException {

    Connection conn = null;

    System.out.println("Starting");

    try {
      // Открываем соединение с базой
      Class.forName("org.postgresql.Driver");
      String query = "select NGr,FIO from groups natural join students order by NGr, FIO";
      conn = DriverManager.getConnection("jdbc:postgresql://localhost/postgres", "postgres", "adminpostgres");

      JasperReport jasperReport = JasperCompileManager.compileReport("Reports/ReportParameters.xml");

      // Передаем conn в отчет

      HashMap Params =new HashMap();
      Params.put("IdGR_Cur",2);
      JasperPrint jasperPrint = JasperFillManager.fillReport( jasperReport, Params, conn );

      JasperExportManager.exportReportToPdfFile(jasperPrint, "Reports/Parameters.pdf");

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } catch (JRException e) {
      e.printStackTrace();
    } finally {
      // Корректно закрываем соединение с базой
      try {
        conn.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    System.out.println("Done.");
  }
}
